package com.gms.web.constant;

import org.springframework.stereotype.Component;

@Component
public class Path {
	public static final String VIEW="/WEB-INF/view/";
	public static final String SEPARATOR="/";
}
