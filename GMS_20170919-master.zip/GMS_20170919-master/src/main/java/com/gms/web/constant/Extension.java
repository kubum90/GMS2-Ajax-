package com.gms.web.constant;

import org.springframework.stereotype.Component;

@Component
public class Extension {
	public static final String JSP=".jsp";
}
