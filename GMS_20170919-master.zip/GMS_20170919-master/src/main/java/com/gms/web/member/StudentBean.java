package com.gms.web.member;

import lombok.Data;

@Data
public class StudentBean {
	private String num,member_id,name,password,ssn,regdate,subj_id,phone,email,profile,gender,subject;
}
