package com.gms.web.constants;

import org.springframework.stereotype.Component;

@Component
public class PATH {
	public static final String VIEW= "/WEB-INF/view/";
	public static final String SEPARARTOR= "/";
}
