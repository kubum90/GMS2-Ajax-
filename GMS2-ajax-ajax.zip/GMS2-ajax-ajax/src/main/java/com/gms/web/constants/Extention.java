package com.gms.web.constants;

import org.springframework.stereotype.Component;

@Component
public class Extention {
	public static final String JSP=".jsp";
}
