package com.gms.web.board;


import org.springframework.stereotype.Component;

@Component
public interface BoardService {
	
	
}
