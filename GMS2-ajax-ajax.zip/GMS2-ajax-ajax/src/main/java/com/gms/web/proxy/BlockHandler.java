package com.gms.web.proxy;

import org.springframework.stereotype.Component;

@Component
public class BlockHandler{

   public static int [] attr(PageProxy pxy) {
      int[]result=new int[6];
      int theNumberOfPages=0,
            startPage=0,
            endPage=0;
      theNumberOfPages = (pxy.getTheNumberOfRows() % pxy.getPageSize())==0 ?
            pxy.getTheNumberOfRows() / pxy.getPageSize()
            : pxy.getTheNumberOfRows() / pxy.getPageSize() +1;
      startPage = pxy.getPageNumber() - ((pxy.getPageNumber() -1) % pxy.getBlockSize());
      endPage= (startPage + pxy.getBlockSize() -1 <= theNumberOfPages)?
            startPage+pxy.getBlockSize() - 1 : theNumberOfPages;
      
      result[0]=pxy.getPageNumber();
      result[1]=theNumberOfPages;
      result[2]=startPage;
      result[3]=endPage;
      result[4]=startPage-(theNumberOfPages/pxy.getBlockSize()); //prevBlock
      if (result[4]>0) {
          if (theNumberOfPages > startPage + 4) {
             result[5] = 0;
          }
          else {
             result[5] = 1;
          }
       } 
      System.out.println(
    		"pageNumber is "+result[0]+",\n "+
    		"theNumberOfPages is "+result[1]+",\n " +
    		"startPage is "+result[2]+",\n " +
    		"endPage is "+result[3]+",\n " +
    		"prevBlock is "+result[4]+",\n " +
    		"nextBlock is "+result[5]    		
    		  );
      return result;
   }
}