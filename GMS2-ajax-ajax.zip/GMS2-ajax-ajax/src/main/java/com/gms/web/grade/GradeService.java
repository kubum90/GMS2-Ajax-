package com.gms.web.grade;

import org.springframework.stereotype.Component;

@Component
public interface GradeService {
	
}