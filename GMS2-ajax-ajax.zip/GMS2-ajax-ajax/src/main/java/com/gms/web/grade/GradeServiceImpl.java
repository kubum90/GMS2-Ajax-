package com.gms.web.grade;

import org.springframework.stereotype.Service;

import com.gms.web.member.MemberService;

@Service
public class GradeServiceImpl implements GradeService {
}
